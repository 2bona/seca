self.__precacheManifest = [
  {
    "revision": "a7dc4286cb8392d44a38",
    "url": "/css/Register-vendor.9bb2d722.css"
  },
  {
    "revision": "a7dc4286cb8392d44a38",
    "url": "/js/Register-vendor.894b0dd2.js"
  },
  {
    "revision": "81eb70f58370fa644e53",
    "url": "/css/Register-vendor~adminedit~adminorder~items~login~offlinepage~orders~passcode~register~reset~resetpas~bb408f4d.976b6bb8.css"
  },
  {
    "revision": "81eb70f58370fa644e53",
    "url": "/js/Register-vendor~adminedit~adminorder~items~login~offlinepage~orders~passcode~register~reset~resetpas~bb408f4d.ccf1a520.js"
  },
  {
    "revision": "a99301e2e2e323da6f3f",
    "url": "/css/Register-vendor~adminedit~adminorder~items~offlineorders~offlinepage~orders~reviews~summary~vendorre~047c82f5.2c43f411.css"
  },
  {
    "revision": "a99301e2e2e323da6f3f",
    "url": "/js/Register-vendor~adminedit~adminorder~items~offlineorders~offlinepage~orders~reviews~summary~vendorre~047c82f5.de4ddb6f.js"
  },
  {
    "revision": "3f542a9f8c4a01058d9b",
    "url": "/css/Register-vendor~adminedit~items~orders~summary.a5873347.css"
  },
  {
    "revision": "3f542a9f8c4a01058d9b",
    "url": "/js/Register-vendor~adminedit~items~orders~summary.cc15b606.js"
  },
  {
    "revision": "6c75182546265f09fde1",
    "url": "/css/adminedit.edf8eabc.css"
  },
  {
    "revision": "6c75182546265f09fde1",
    "url": "/js/adminedit.aa8e9dbd.js"
  },
  {
    "revision": "407368eefaa0450c2c04",
    "url": "/css/adminedit~adminorder~items~offlineorders~offlinepage~orders~reviews~summary.eb36d075.css"
  },
  {
    "revision": "407368eefaa0450c2c04",
    "url": "/js/adminedit~adminorder~items~offlineorders~offlinepage~orders~reviews~summary.0037655f.js"
  },
  {
    "revision": "f8fcf2b2adac3fa3dfa1",
    "url": "/css/adminorder.034b4c2f.css"
  },
  {
    "revision": "f8fcf2b2adac3fa3dfa1",
    "url": "/js/adminorder.dbc4da46.js"
  },
  {
    "revision": "bec2ad4864fdc562c31e",
    "url": "/css/app.3610c653.css"
  },
  {
    "revision": "bec2ad4864fdc562c31e",
    "url": "/js/app.3420bc56.js"
  },
  {
    "revision": "2809b4d088a9fec0b44a",
    "url": "/css/authpage.5ee2d303.css"
  },
  {
    "revision": "2809b4d088a9fec0b44a",
    "url": "/js/authpage.51669b87.js"
  },
  {
    "revision": "5fa98337b410727d563a",
    "url": "/css/chunk-vendors.9edab911.css"
  },
  {
    "revision": "5fa98337b410727d563a",
    "url": "/js/chunk-vendors.dcf7a37a.js"
  },
  {
    "revision": "3393ffa725833eea01a8",
    "url": "/css/index.1ca6bb00.css"
  },
  {
    "revision": "3393ffa725833eea01a8",
    "url": "/js/index.e6e452aa.js"
  },
  {
    "revision": "0844be36a1b08232ce47",
    "url": "/css/items.a6e275fe.css"
  },
  {
    "revision": "0844be36a1b08232ce47",
    "url": "/js/items.2d87f64d.js"
  },
  {
    "revision": "b21cf55b8f518903177d",
    "url": "/js/login.f7f93176.js"
  },
  {
    "revision": "a7c7a42133a81e701663",
    "url": "/css/offlineorders.3610c653.css"
  },
  {
    "revision": "a7c7a42133a81e701663",
    "url": "/js/offlineorders.655ccd74.js"
  },
  {
    "revision": "33ee63d2a3fb36538607",
    "url": "/js/offlineorders~offlinepage.6f99e429.js"
  },
  {
    "revision": "e934e101c6e9de06a7aa",
    "url": "/css/offlinepage.252f0bd6.css"
  },
  {
    "revision": "e934e101c6e9de06a7aa",
    "url": "/js/offlinepage.951bbda6.js"
  },
  {
    "revision": "4445784f4e0ba6a43688",
    "url": "/css/orders.fa86f653.css"
  },
  {
    "revision": "4445784f4e0ba6a43688",
    "url": "/js/orders.f136a250.js"
  },
  {
    "revision": "160105d1f61049cc73c7",
    "url": "/js/passcode.f1d60add.js"
  },
  {
    "revision": "e094c2b3677330eb98e9",
    "url": "/js/register.ccd50259.js"
  },
  {
    "revision": "6b25de1df6f3ded915e0",
    "url": "/js/reset.9b061312.js"
  },
  {
    "revision": "b03e1c7b02a76c7d46f2",
    "url": "/js/resetpass.9f11538f.js"
  },
  {
    "revision": "65c005f7172330a12f46",
    "url": "/js/resetpasscode.ab649d4f.js"
  },
  {
    "revision": "c7c294afbbdcd60dba22",
    "url": "/css/reviews.1fef65fa.css"
  },
  {
    "revision": "c7c294afbbdcd60dba22",
    "url": "/js/reviews.b2fb0a83.js"
  },
  {
    "revision": "62bc97f3dcc795ef3a7d",
    "url": "/js/setpassword.ec0c2d16.js"
  },
  {
    "revision": "a89d0df7afff1d84f298",
    "url": "/css/summary.58d7ac7d.css"
  },
  {
    "revision": "a89d0df7afff1d84f298",
    "url": "/js/summary.8fc4351d.js"
  },
  {
    "revision": "90afa92ecf63629a6d27",
    "url": "/css/vendoradmin.f300ca17.css"
  },
  {
    "revision": "90afa92ecf63629a6d27",
    "url": "/js/vendoradmin.e986d898.js"
  },
  {
    "revision": "c2b796e4a262328ea69e",
    "url": "/css/vendorreview.e9a01353.css"
  },
  {
    "revision": "c2b796e4a262328ea69e",
    "url": "/js/vendorreview.421bb793.js"
  },
  {
    "revision": "feb21c469dad4bdfb1aa",
    "url": "/css/vendorsale.0bff9f69.css"
  },
  {
    "revision": "feb21c469dad4bdfb1aa",
    "url": "/js/vendorsale.85420558.js"
  },
  {
    "revision": "79e192d9ce23f5ab758f",
    "url": "/css/vendortable.ea429b05.css"
  },
  {
    "revision": "79e192d9ce23f5ab758f",
    "url": "/js/vendortable.298423c3.js"
  },
  {
    "revision": "ec3cfddedb8bebd2d7a3fdf511f7c1cc",
    "url": "/fonts/fa-brands-400.ec3cfdde.woff"
  },
  {
    "revision": "f89ea91ecd1ca2db7e09baa2c4b156d1",
    "url": "/fonts/fa-regular-400.f89ea91e.woff"
  },
  {
    "revision": "13685372945d816a2b474fc082fd9aaa",
    "url": "/fonts/fa-brands-400.13685372.ttf"
  },
  {
    "revision": "c20b5b7362d8d7bb7eddf94344ace33e",
    "url": "/fonts/fa-regular-400.c20b5b73.woff2"
  },
  {
    "revision": "a06da7f0950f9dd366fc9db9d56d618a",
    "url": "/fonts/fa-brands-400.a06da7f0.woff2"
  },
  {
    "revision": "c1868c9545d2de1cf8488f1dadd8c9d0",
    "url": "/fonts/fa-brands-400.c1868c95.eot"
  },
  {
    "revision": "db78b9359171f24936b16d84f63af378",
    "url": "/fonts/fa-regular-400.db78b935.ttf"
  },
  {
    "revision": "a0369ea57eb6d3843d6474c035111f29",
    "url": "/fonts/fa-solid-900.a0369ea5.eot"
  },
  {
    "revision": "261d666b0147c6c5cda07265f98b8f8c",
    "url": "/fonts/fa-regular-400.261d666b.eot"
  },
  {
    "revision": "b15db15f746f29ffa02638cb455b8ec0",
    "url": "/fonts/fa-solid-900.b15db15f.woff2"
  },
  {
    "revision": "bea989e82b07e9687c26fc58a4805021",
    "url": "/fonts/fa-solid-900.bea989e8.woff"
  },
  {
    "revision": "1ab236ed440ee51810c56bd16628aef0",
    "url": "/fonts/fa-solid-900.1ab236ed.ttf"
  },
  {
    "revision": "89ffa3aba80d30ee0a9371b25c968bbb",
    "url": "/img/fa-regular-400.89ffa3ab.svg"
  },
  {
    "revision": "0cb5a5c0d251c109458c85c6afeffbaa",
    "url": "/img/fa-brands-400.0cb5a5c0.svg"
  },
  {
    "revision": "ec763292e583294612f124c0b0def500",
    "url": "/img/fa-solid-900.ec763292.svg"
  },
  {
    "revision": "d0066537ab6a4c6f8285a5aeb3ba5f09",
    "url": "/fonts/materialdesignicons-webfont.d0066537.woff2"
  },
  {
    "revision": "b4917be25082eb793b5363f2fdb5f282",
    "url": "/fonts/materialdesignicons-webfont.b4917be2.woff"
  },
  {
    "revision": "2d0a0d8f5f173be15a67aa084db94fe6",
    "url": "/fonts/materialdesignicons-webfont.2d0a0d8f.eot"
  },
  {
    "revision": "f51112347be6b44f9ef46151a971430d",
    "url": "/fonts/materialdesignicons-webfont.f5111234.ttf"
  },
  {
    "revision": "ac5f61cbb92e7b9fa4e7d5f3bee19d4a",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];